import socket
import struct
import base64
import cv2
import datetime
import numpy as np
import pickle
from tkinter import *
from threading import Thread
import concurrent.futures
from multiprocessing import Process, Lock



def connect_rover():
    payload_size = struct.calcsize("<L")
    data = b''
    
#    proc1 = Process(target=video_stream, args=(data,payload_size))
#    proc2 = Process(target=send_instruction)
#    proc1.start()
#    proc2.start()
    
    while True:
        master.update()
#        proc1.join()
#        proc2.join()

        video_stream(data,payload_size)

#        print(instruction)
        send_instruction()
        
       
        
def send_instruction():
#    lock.acquire()
    global instruction
    s.send(bytes(instruction, "utf-8"))
    instruction = '0'
#    lock.release()
        
def video_stream(data, payload_size):
#    lock.acquire()
    start_time = datetime.datetime.now()
    # keep receiving data until it gets the size of the msg.
    while len(data) < payload_size:
        data += s.recv(4096)
    # Get the frame size and remove it from the data.
    frame_size = struct.unpack("<L", data[:payload_size])[0]
    data = data[payload_size:]
    # Keep receiving data until the frame size is reached.
    while len(data) < frame_size:
        data += s.recv(131072)
    # Cut the frame to the beginning of the next frame.
    frame_data = data[:frame_size]
    data = data[frame_size:]

    # frame = pickle.loads(frame_data)
    
    # Converting the image to be sent.
    img = base64.b64decode(frame_data)
    npimg = np.frombuffer(img, dtype=np.uint8)
    frame = cv2.imdecode(npimg, 1)

    #frame = cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
    end_time = datetime.datetime.now()
    fps = 1/(end_time-start_time).total_seconds()
    print("Fps: ",round(fps,2))

    # Display
    cv2.imshow('frame', frame)
    
    if (cv2.waitKey(1) & 0xFF == ord('q')):
        cv2.destroyAllWindows()
        exit()
#    lock.release()
    
        
        
        

#def thredVideo():
#    t_vider_connection = Thread(target=connect_rover)
#    t_vider_connection.run()
#    #t_vider_connection.join()


def button1():
    global instruction
    instruction = '1'

def button2():
    global instruction
    instruction = '2'


instruction = '0'
master = Tk()
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(('localhost',1235))

b = Button(master, text="video", command=connect_rover)
b.place(relx=0.5, rely=0.25, anchor=CENTER)

send1 = Button(master, text="button1", command=button1)
send1.place(relx = 0.5, rely=0.5, anchor=CENTER)

send1 = Button(master, text="button2", command=button2)
send1.place(relx = 0.5, rely=0.75, anchor=CENTER)

#concurrent.futures.excecutor = ThreadPoolExecutor(max_workers = 2)
#a = exeecutor.submit(mainloop)
#b = excecutor.submit(connect_rover)

#proc1 = Process(target=mainloop)
#proc2 = Process(target=connect_rover)

#proc1.start()
#proc2.start()
lock = Lock()

mainloop()
