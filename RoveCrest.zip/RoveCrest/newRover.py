import cv2
import numpy as np
import socket
import sys
import struct
import base64
from threading import Thread
from multiprocessing import Process, Lock


def send_video():
    while True:
        ret,frame=cap.read()
        
    #            lock.acquire()
        encoded, buffer = cv2.imencode('.jpg', frame)
        b_frame = base64.b64encode(buffer)
        b_size = len(b_frame)
                    #sending data
        conn_vid.sendall(struct.pack("<L", b_size) + b_frame)
    #        lock.release()
            
def recv_cmd():
    while True:
        msg = conn_cmd.recv(1)
        print(msg.decode("utf-8"))
        

HOST = ''

cap=cv2.VideoCapture(0)

#lock = Lock()

s_vid = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s_cmd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s_cmds = socket.socket(socket.AF_INET,socket.SOCK_STREAM)



s_vid.bind((HOST, 8000))
s_cmd.bind((HOST, 1235))

s_vid.listen(10)
s_cmd.listen(10)

print("Ready to connect")

conn_vid, addr = s_vid.accept()
conn_cmd, addr2 = s_cmd.accept()

print (addr)
print (addr2)

s_cmds.connect(('localhost',1236))

process1 = Thread(target=send_video)
process1.start()

process2 = Thread(target=recv_cmd)
process2.start()

#connect_base()
