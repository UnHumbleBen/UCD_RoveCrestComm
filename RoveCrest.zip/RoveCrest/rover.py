import cv2
import numpy as np
import socket
import sys
import struct
import base64
import pickle
from threading import Thread
from multiprocessing import Process, Lock


def connect_base():
#    proc1.start()
#    proc2.start()

    while True:
#        proc1.join()
#        proc2.join()
        if(send_video()):
            recieve_instruction()
        
            
def send_video():
    ret,frame=cap.read()
#    lock.acquire()
    if (ret):
        encoded, buffer = cv2.imencode('.jpg', frame)
        b_frame = base64.b64encode(buffer)
        b_size = len(b_frame)
            #sending data
        connection.sendall(struct.pack("<L", b_size) + b_frame)
        return 1
#    lock.release()
    else:
        return 0


def recieve_instruction():
#    lock.acquire()
    msg = connection.recv(16).decode("utf-8")
    if(msg == '1'):
        print ("Button 1 pressed")
    elif (msg == '2'):
        print ("Button 2 pressed")
#    lock.release()
            

HOST = ''
PORT = 1235

cap=cv2.VideoCapture(0)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(10)
print("Ready to connect")
connection, addr = s.accept()
print (addr)


lock = Lock()

proc1 = Process(target=send_video)
proc2 = Process(target=recieve_instruction)
#
#proc1.start()
#proc2.start()
##
#proc1.join()
#proc2.join()


connect_base()
